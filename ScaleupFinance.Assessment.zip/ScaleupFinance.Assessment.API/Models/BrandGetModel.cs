﻿namespace ScaleupFinance.Assessment.API.Models
{
    public class BrandGetModel
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
